package com.demo.test;
import com.demo.stackqueue.*;

public class TestStackList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyStackList ob=new MyStackList();
		
		ob.pop();
		ob.push(45);
		ob.push(67);
		System.out.println("Poped elements: " +ob.pop());
		
		
			
		
			
		

	}

}
