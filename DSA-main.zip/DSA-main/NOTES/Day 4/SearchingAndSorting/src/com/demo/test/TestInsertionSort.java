package com.demo.test;

import com.demo.sorting.InsertionSortAlgorithm;

public class TestInsertionSort {

	public static void main(String[] args) {
		int[] arr= {21,11,13,22,25,7,10,8,1};
		//InsertionSortAlgorithm.insertionSortAscending(arr);
		InsertionSortAlgorithm.insertionSortDescending(arr);
	}

}
