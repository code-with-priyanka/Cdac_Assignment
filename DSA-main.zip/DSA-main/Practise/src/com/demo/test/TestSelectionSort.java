package com.demo.test;

import com.demo.beans.SelectionSort;

public class TestSelectionSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {54,52,23,55,11,56,58,10,11};
		SelectionSort so = new SelectionSort();
		so.selectionSort(arr);
	}

}
