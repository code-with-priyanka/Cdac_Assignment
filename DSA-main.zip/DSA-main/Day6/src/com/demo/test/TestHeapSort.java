package com.demo.test;

import com.demo.sorting.HeapSort;

public class TestHeapSort {

	public static void main(String[] args) {
		int arr[]= {2,12,3,45,1,48,45,65,1,23,5};
		HeapSort.heapSort(arr);
	}

}
