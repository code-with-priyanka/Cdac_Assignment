package com.demo.test;

import java.util.stream.IntStream;

import com.demo.sorting.Sorting;

public class TestSorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int arr[]= {21,2,5,1,7,8,10,3};
//		Sorting.bubblesort(arr);
		Sorting.BubbleSortImprvd(arr);

	}

}
