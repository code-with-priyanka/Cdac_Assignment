package com.demo.Test;

import com.demo.Sorting.CountingSort;

public class TestCountingSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {23,12,5,2,45,1,4,6,8,6,9};
		CountingSort.CountingSort(arr);
	}

}
