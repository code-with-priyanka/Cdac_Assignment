package com.demo.Test;

import com.demo.Sorting.MergeSort;

public class TestMergeSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr= {20,5,7,11,21,2,7,25,30,3};
		MergeSort.MergeSortAssending(arr, 0, arr.length-1);

	}

}
