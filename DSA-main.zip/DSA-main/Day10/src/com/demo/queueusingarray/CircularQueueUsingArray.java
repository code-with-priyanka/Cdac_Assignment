package com.demo.queueusingarray;

public class CircularQueueUsingArray {

	int[] arr;
	int front;
	int rear;
	
	public CircularQueueUsingArray() {
		arr=new int[15];
		front=-1;
		rear=-1;
	}
	public CircularQueueUsingArray(int size) {
		arr=new int[size];
		front=-1;
		rear=-1;
		
	}
	public boolean isEmpty() {
		if(front ==-1) {
			System.out.println("Queue is empty");
			return true;
		}
		return false;
	}
	boolean isfull() {
	    return (rear + 1) % arr.length == front;
	}

	public boolean enqueue(int num) {
		if(!isfull()) {
			if(front==-1) {
				front=0;
			}
			rear=(rear+1)%arr.length;
			arr[rear]=num;
			System.out.println("Added Successfully " +num);
			return true;
		}
		return false;
		
	}
	public int dequeue() {
		if(!isEmpty()) {
			int n=arr[front];
			if(front==rear) {
				front=-1;
				rear=-1;
			}else {
				front=(front-1)%arr.length;
			}
			return n;
		}
		return -1;
	}
}
