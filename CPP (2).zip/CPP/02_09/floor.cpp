#include <iostream>  
#include<math.h>  
using namespace std;  
int main()  
{  
 float x=-7.8;  
cout<<"Now, the value of x is :"<<floor(x);  
 return 0;  
} 