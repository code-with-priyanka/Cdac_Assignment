#include <iostream>  
#include<cmath>  
using namespace std;  
int main()  
{  
  float x=-9.2;  
   cout<<"final value of x is :"<<ceil(x);  
  return 0;  
} 
