// CPP Program to demonstrate errors in double sqrt()
#include <cmath>
#include <iostream>
using namespace std;
int main()
{
    double answer;
    answer = sqrt(-10);
    cout << "Square root of " << " is " << answer;
     return 0;
}