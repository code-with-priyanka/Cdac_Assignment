 #include<iostream>
using namespace std;
class Student
{
	int rollno;
	char DOB;
	int total;
	public:
		void accept()
		{
			cout<<"enter rollno for student\n";
			cin>>rollno;
			cout<<"enter rollno for student\n";
			cin>>DOB;
			cout<<"enter rollno for student\n";
			cin>>total;			       
		}	
        void display()	
        {
            cout<<rollno<<"\t"<<DOB<<"\t"<<total<<"\t";
        }
};
  
  int main()
  {
    Student* ptr =new Student[10];
    cout<<"accept details\n";
    for(int i=0;i<3;i++)
    ptr[i].accept();  
    cout<<"display details\n";
    for(int i=0;i<3;i++)
    ptr[i].display();
}

