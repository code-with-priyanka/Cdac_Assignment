#include <iostream>
#include <string>
using namespace std;

class Student {
    int rollno;
    string DOB;
    int total;
public:
    void accept() {
        cout<<"Enter roll number:";
        cin>>rollno;
        cout<<"Enter DOB";
        cin>>DOB;
        cout<<"Enter total marks:";
        cin>>total;
    }
    void display() {
        cout<<rollno<<"\t"<<DOB<<"\t"<<total<<"\n";
    }
    int getRollno() {
        return rollno;
    }
};

void sortRollno(Student* arr, int n) {    
    for (int i=0; i<n-1; i++) 
    {
        for (int j=i+1; j<n; j++) {
            Student temp;
            if (arr[i].getRollno() > arr[j].getRollno()) {
                // swap(arr[i], arr[j]);
                temp=arr[i];
                arr[i]=arr[j];
                arr[j]=temp;
            }
        }
    }
}

int main() {
    int n=4;
    Student* ptr=new Student[n];
    cout <<"Accept data of students:\n";
    for (int i=0; i<n; i++)
    {
        ptr[i].accept();
    }
    sortRollno(ptr,n); 
    cout <<"\nDisplay sorted data:\n";
    for (int i=0; i<n; i++)
        ptr[i].display();
}
