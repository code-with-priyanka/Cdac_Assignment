#include<iostream>
using namespace std;
int main()
{
    int num,fact=1,i;
    cout<<"Enter the no:";//5
    cin>>num;
    for(i=1;i<=num;i++)
    {
        fact=fact*i;//32
    }
    cout<<"factorial is:" <<fact;
}
