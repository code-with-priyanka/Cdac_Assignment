#include<iostream>
using namespace std;
int main()
{
    int base,exp,Power=1,i;
    cout<<"Enter Base and its Exponent: ";
    cin>>base>>exp;
    for(i=1;i<=exp;i++)
    {
        Power=Power*base;
    }
    cout<<"\nPower is: "<<Power;
}