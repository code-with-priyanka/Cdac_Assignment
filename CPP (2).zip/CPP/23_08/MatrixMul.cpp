#include<iostream>
using namespace std;

int main()
{
    int i,j,k,sum;
    int a[3][3]={1,2,3,4,5,6,7,8,9};
    int b[3][3]={1,2,3,4,5,6,7,8,9};
    int m[3][3];

    for(i=0;i<=2;i++)
    {
        for(j=0;j<=2;j++)
        {   
            sum=0;
            for(k=0;k<=2;k++)
            {
                sum=sum+a[i][k]*b[k][i];
            }
            m[i][j]=sum;
        }
    }
    for(i=0;i<=2;i++)
    {
        for(j=0;j<=2;j++)
        {
            cout<<m[i][j]<<"\t";
        }
        cout<<endl;
    }
    

}