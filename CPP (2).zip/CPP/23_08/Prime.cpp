#include<iostream>
using namespace std;
int main()
{
    int num,count=0; 
    cout<<"Enter any number"<<endl;
    cin>>num; //11//6
    int i=2;
    while(i<num) 
    {
        if(num%i==0) 
        {
            cout<<"Not Prime Number";
            break;
            count=1;
        }
        i++;
    }
    if(count==0)
    {
        cout<<"Prime Number";
    }
}