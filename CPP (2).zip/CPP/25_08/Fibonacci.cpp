#include<iostream>
using namespace std;
int main()
{
    int a=0, b=1, n;
    cout<<"Enter number of elements:"<<endl;
    cin>>n;
    if(n>=1){
        cout<<a<<"\t";
    }
    if(n>=2){
        cout<<b<<"\t";
    }
    for(int i=1; i<=n-2; i++)
    {
        int c=a+b;
        cout<<c<<"\t";
        a=b;
        b=c; 
    }

}