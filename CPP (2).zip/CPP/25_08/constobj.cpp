#include <iostream>  
using namespace std;  
class ABC  
{  
	public:  
	int A;    
	ABC ()  //constructor
	{  
		A = 10; 
	}  
};  
int main ()  
{  
const ABC obj;  
cout << " The value of A: " << obj.A << endl;  
//obj.A = 20; // cant update value of const object
cout << " The value of A: " << obj.A << endl;  
return 0;  
}  