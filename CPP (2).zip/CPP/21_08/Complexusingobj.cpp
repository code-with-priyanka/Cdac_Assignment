#include<iostream>
using namespace std;
class Complex{
    int real,img;
    public:
    void accept();
    void display();
    void setReal(int);
    int getReal() ;

};
void Complex :: accept(){
    cout<<"Enter values or real and imaginary part: ";
    cin>>real>>img;
}
void Complex :: setReal(int r){
    real=r;
}
int Complex :: getReal() 
{
    return real;
}
void Complex :: display() 
{
    cout<<"complex no is:\n"<<real<<"+"<<img<<"i";
} 
int main()
{
    Complex c1;
    cout<<"Address of object is: "<<&c1<<endl;
    c1.accept();
    c1.display();
    c1.setReal(10);
    c1.getReal();
    cout<<"\nrealpart\n"<<c1.getReal();
}