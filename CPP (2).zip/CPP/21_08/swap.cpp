#include<iostream>
using namespace std;
void swap(int&,int&);
int main(){
    int a=10,b=20;
    cout<<"before calling swap function:\n";
    cout<<"\na is:"<<a<<"\t"<<"b is:"<<b;
    swap(a,b);
    cout<<"\nafter calling swap function:\n";
    cout<<"\na is:"<<a<<"\t"<<"b is:"<<b;
    
}
void swap(int& p,int& q){
//    int temp;
//    temp=p;
//    p=q;
//    q=temp;
    p=p+q;//30;
    q=p-q;//10
    p=p-q;//20
   cout<<"\nin swap function:\n";
   cout<<"\np is:"<<p<<"\t"<<"q is:"<<q;
}