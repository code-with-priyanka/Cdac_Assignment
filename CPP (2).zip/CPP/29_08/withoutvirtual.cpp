//case 1: object creation on stack with out virtual keyword
#include<iostream>
using namespace std;
class employee{
        int id;
        public:
        employee();
        employee(int);

        void display();
        int findsalary(){
            return 0;
        }
};
employee :: employee(){
            cout<<"In default of employee:\n";
            id=0;
}
employee :: employee(int i){
            cout<<"In Para of employee:\n";
            id=i;
}
void employee :: display(){
            cout<<"id of employee is :"<<id;      
}
class wageemployee : public employee{

            int hrs,date;
            public:
            wageemployee();
            wageemployee(int,int,int);
            void display();
            int findsalary();
};
wageemployee :: wageemployee(){

            cout<<" In default of wage \n";
            hrs=0;
            date=0;
}
wageemployee :: wageemployee(int i,int h,int r) : employee(i){

            cout<<"in para of wage:\n";
            hrs=h;
            date=r;
}
int wageemployee :: findsalary(){

            return hrs*date;

}
void wageemployee :: display(){

            employee::display();
            cout<<hrs<<endl;
            cout<<date<<endl;
}

int main(){
    employee* ptr;//stactic type
    wageemployee w1(13,234,34);//static type
    ptr=&w1;
    cout<<"salary is:"<<ptr->findsalary();//without virtual keyword binding takes
    ptr->display();
}
