#include<iostream>
using namespace std;
class A
{
    public:
       virtual ~A()
       {
            cout<<"In A's Destructor";
       }
};
class B :  public A 
{
    public:
    ~B()
    {
        cout<<"In B's Destructor";
    }
};

int main(){
    A * ptr=new B();
    delete ptr;
}

