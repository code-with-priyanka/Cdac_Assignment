#include<iostream>
using namespace std;
int main(){
    int a,b,temp;
    cout<<"enter the 2 no:";
    cin>>a>>b;
    cout<<"before swapping a is:"<<a<<"\tb is :"<<b<<endl;

    temp=a;
    a=b;
    b=temp;
    cout<<"after swapping a is:"<<a<<"\tb is :"<<b;

}