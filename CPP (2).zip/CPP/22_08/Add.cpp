#include<iostream>
using namespace std;
int main()
{
    //Addition of 2 Digits
    // int a,b, add;
    // cout<<"Enter two digits: ";
    // cin>>a>>b;
    // add=a+b;
    // cout<<"\nAddition of 2 digits is: "<<add<<endl;

    //Addition of 2 Binary numbers
    // int a,b,add;
    // cout<<"Enter Binary numbers: ";
    // cin>>a>>b;
    // add=a&&b;
    // cout<<"\nAddition of 2 Binary numbers is: "<<add<<endl;

    //Addition of two charactors
    char a,b;
    int add;
    cout<<"Enter two charactors: ";
    cin>>a>>b;
    add=(int)a+b;
    cout<<"\nAddition of 2 charactors is: "<<add<<endl;
}