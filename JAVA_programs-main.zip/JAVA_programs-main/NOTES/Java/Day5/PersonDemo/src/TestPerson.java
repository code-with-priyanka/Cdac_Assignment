
public class TestPerson {

	public static void main(String[] args) {
		Person p1=new Person("Rohit");
		System.out.println(p1);
		Person p2=new Person("Sayali");
		System.out.println(p2);
		Person p3=new Person("Arundhati");
		System.out.println(p3);
		
	}

}
