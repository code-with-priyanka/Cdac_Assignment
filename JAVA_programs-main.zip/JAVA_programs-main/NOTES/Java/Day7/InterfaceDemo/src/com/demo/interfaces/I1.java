package com.demo.interfaces;

public interface I1 {
  void m1();
  void m2(int x);
  int i=12;
//  default void m4() {
//	  System.out.println("in m4 method in I1");
//  }
}
