package com.demo.interfaces;

public interface MyGeneric2<T extends Number> {
       T m1(T x,T y);
}
