package com.demo.interfaces;

public interface I2 {
    void m2(int x);
    void m3();
//    default void m4() {
//  	  System.out.println("in m4 method in I2");
//    }
}
