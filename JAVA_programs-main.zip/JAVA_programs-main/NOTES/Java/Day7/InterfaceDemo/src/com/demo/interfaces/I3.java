package com.demo.interfaces;

public interface I3 extends I1,I2{

}
