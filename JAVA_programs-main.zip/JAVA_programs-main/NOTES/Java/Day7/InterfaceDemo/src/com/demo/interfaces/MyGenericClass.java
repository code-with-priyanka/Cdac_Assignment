package com.demo.interfaces;

//public interface MyGenericClass<T,F> {
public interface MyGenericClass<T> {
	T compare(T x,T y);
	//F m1(T x,F y);

}

