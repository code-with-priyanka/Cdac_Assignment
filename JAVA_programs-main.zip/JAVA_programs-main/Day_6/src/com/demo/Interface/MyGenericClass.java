package com.demo.Interface;

public interface MyGenericClass<T>{
	T compare(T x, T y);

}
