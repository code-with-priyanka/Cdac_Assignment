package com.demo.Interface;

public interface I3 extends I1,I2{

}
