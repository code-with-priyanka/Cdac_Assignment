package com.demo.Interface;

public interface MyGeneric2<T extends Number> {
	T m1(T x, T y);
	

}
