package com.demo.Interface;

public interface I2 {
    void m2(int x);
    void m3();

}
