package com.demo.beans;

public interface MyComparable {
	public static int compare(int a, int b) {
		System.out.println("In compare method");
		return 10;
	}

}
