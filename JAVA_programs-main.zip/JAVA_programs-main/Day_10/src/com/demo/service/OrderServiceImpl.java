package com.demo.service;

import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.demo.beans.Customer;
import com.demo.beans.Item;
import com.demo.dao.OrderDao;
import com.demo.dao.OrderDaoImpl;
import java.util.ArrayList;
public class OrderServiceImpl implements OrderService {
private OrderDao odao;
private Object nm;
    
	public OrderServiceImpl() {
		super();
		odao=new OrderDaoImpl();
	}

	@Override
	public boolean addNewCustomer() {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter id : ");
		int cid=sc.nextInt();
		System.out.println("Enter Name : ");
		String nm= sc.next();
		System.out.println("Enter Mobile: ");
		String mob=sc.next();
		Customer c=new Customer(cid,nm,mob);
		List <Item> lst=new ArrayList<>();
		String ans=null;
		do {
			System.out.println("Enter item id: ");
			int id=sc.nextInt();
			System.out.println("Enter item name: ");
			String inm=sc.next();
			System.out.println("Enter item Quantity: ");
			int qty=sc.nextInt();
			System.out.println("Enter item price: ");
			Double price = sc.nextDouble();
			Item item=new Item(id,inm,qty,price);
			lst.add(item);
			System.out.println("Do you want to continue(y/n)?");
			ans=sc.next();
		
		}while(ans.equals("y"));
		
		
		return odao.save(c,lst);
	}

	@Override
	public Map<Customer, List<Item>> displayAll() {
		// TODO Auto-generated method stub
		
		return odao.findAll();
	}

	@Override
	public Set<Customer> displaybyCustomer(String cnm) {
		// TODO Auto-generated method stub
		return odao.findByName(nm);
	}


	



}
