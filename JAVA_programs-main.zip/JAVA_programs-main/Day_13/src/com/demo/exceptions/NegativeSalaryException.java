package com.demo.exceptions;

public class NegativeSalaryException extends Exception{
	public NegativeSalaryException(String msg) {
		super(msg);
	}

}
